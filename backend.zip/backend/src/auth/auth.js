import express from 'express'
import passport from 'passport'
import localStrategy from 'passport-local'
import crypto, { hash } from 'crypto'
import { Mongo } from '../database/mongo.js'
import jwt from 'jsonwebtoken'
import { ObjectId } from 'mongodb' //mongo coloca um id unico para cada usuario


const collectionName = 'users'

passport.use(new localStrategy.Strategy({usernameField: 'email'}, async (email, password, callback) => {
    const user = await Mongo.db
    .collection(collectionName)
    .findOne({email: email})

    if (!user){
        return callback(null, false)
    }

    const saltBuffer = user.salt.saltBuffer //salva junto com os dados do usuario, senha criptografada, mas com a chave pra descriptografar
    
    crypto.pbkdf2(passport, saltBuffer, 310000, 16, 'sha256', (err, hashedPassword) => {//numeros default do nodejs para criptografia de senha
        if(err){
            return callback(null, false)
        }

        const userPasswordBuffer = Buffer.from(user.password.passwordBuffer) //como o mongo salva o dado no banco, transforma em buffer 

        if (!crypto.timingSafeEqual(userPasswordBuffer, hashedPassword)){ {
            return callback(null, false)
        }

        const {password, salt, ...rest} = user //objeto user com dados do usuario, mas sem senha e salt

        return callback(null, rest)
    }})
}))

const authRouter = express.Router()

authRouter.post('/signup', async (req, res) => { //post envia algo ao servidor
    const checkUser = await Mongo.db
    .collection(collectionName)
    .findOne({email: req.body.email})

    if (checkUser){
        return res.status(500).send({
            success: false,
            statusCode: 500,
            body: {
                text: 'User already exists'
            }
        })
    }

    const salt = crypto.randomBytes(16); //gera a chave para criptografia 
    crypto.pbkdf2(req.body.password, salt, 310000, 16, 'sha256', async (err, hashedPassword) => {
        if (err){
            return res.status(500).send({
            success: false,
            statusCode: 500,
            body: {
                text: 'Error on crypto password',
                err: err
            }
            })
        }

        const result = await Mongo.db
        .collection(collectionName)
        .insertOne({
            email: req.body.email,
            password: hashedPassword,
            salt //chave de criptografia
        })

        if (result.insertedId){
            const user = await Mongo.db
            .collection(collectionName)
            .findOne({_id: new ObjectId(result.insertedId)})

            const token = jwt.sign(user, 'secret')

            return res.send({
                success: true, 
                statusCode: 200,
                body: {
                    text: 'User registered successfully',
                    token, 
                    user, 
                    loggedIn: true
                }
            })
        }
    })
})

export default authRouter